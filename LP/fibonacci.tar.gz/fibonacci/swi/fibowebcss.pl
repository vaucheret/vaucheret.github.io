:- use_module(library(http/http_server)).
:- use_module(library(http/html_write)).
:- use_module(library(www_browser)).
:- use_module(library(http/html_head)).

:- http_handler(root(fibonacchi),handlerfibo,[]).


server(Port) :-
    http_server(http_dispatch, [port(Port)]).


:- server(6500).
:- www_open_url('http:/localhost:6500/fibonacchi').


handlerfibo(Request) :-
    http_parameters(Request,[numero(AN,[default('0')])]),
    atom_number(AN,N),
    f(N,F),number_chars(F,SF),
    reply_html_page([
		title("Numero de Fibonacci"),
		meta([name=viewport, content='width=device-width, initial-scale=1'])
		       ],
		    [
 		     \html_requires("https://www.w3schools.com/w3css/5/w3.css"),
		      header(class="w3-container w3-teal",h1(class="w3-jumbo","Numero de Fibonacci")),
			form([class="w3-container w3-light-green w3-margin w3-padding-16",method="post",action="/fibonacchi"],
			     [
				 label(class("w3-text-white"),"El numero de Fibonacci de"),
				 input([class="w3-input",type="text",name="numero",placeholder="Entre el Numero",size="12",autofocus, required],[]),
			     div(span(class="w3-xxlarge",["es el numero ",b("~s"-[SF])])),
                         input([class="w3-btn w3-white",type="submit",value="Calcular"],[])
		    ]),
    		 footer(class("w3-container w3-teal w3-xlarge w3-center"),"Powered by swi-prolog and w3.css")
		    ]).


	


f(0,1).
f(1,1).
f(N,R):-
    N >=2,
    faux(2,N,1,1,R).

faux(N,N,A1,A2,R) :- !,R is A1 + A2.
faux(I,N,A1,A2,R) :-
    I1 is I + 1,
    A is A1 + A2,
    faux(I1,N,A2,A,R).




